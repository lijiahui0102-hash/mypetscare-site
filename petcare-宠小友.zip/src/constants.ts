import { Service, Feeder, Pet } from './types';

export const SERVICES: Service[] = [
  {
    id: '1',
    title: '上门喂食',
    description: '准时上门，按量喂食，清洗水碗',
    icon: 'UtensilsCrossed',
    price: 35,
  },
  {
    id: '2',
    title: '陪玩铲屎',
    description: '30分钟陪玩互动，清理猫砂/遛狗',
    icon: 'Heart',
    price: 50,
  },
  {
    id: '3',
    title: '全程直播',
    description: '专业摄像头全程同步，实时监控',
    icon: 'Video',
    price: 15,
  },
  {
    id: '4',
    title: '简单护理',
    description: '梳毛、剪指甲、擦拭眼角',
    icon: 'Scissors',
    price: 25,
  },
];

export const FEEDERS: Feeder[] = [
  {
    id: 'f1',
    name: '林小月',
    rating: 4.9,
    reviews: 128,
    price: 35,
    avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=moon',
    experience: '3年经验 | 资深猫奴',
    tags: ['细心', '有爱心', '懂急救'],
  },
  {
    id: 'f2',
    name: '陈大伟',
    rating: 4.8,
    reviews: 86,
    price: 40,
    avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=dave',
    experience: '5年经验 | 训犬师背景',
    tags: ['效率高', '体力好', '专业'],
  },
  {
    id: 'f3',
    name: '苏珊',
    rating: 5.0,
    reviews: 245,
    price: 45,
    avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=susan',
    experience: '4年经验 | 宠物护理专业',
    tags: ['金牌服务', '全能选手', '超温柔'],
  },
];

export const MOCK_PETS: Pet[] = [
  {
    id: 'p1',
    name: '大白',
    type: 'cat',
    breed: '布偶猫',
    age: 2,
    imageUrl: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?q=80&w=2043&auto=format&fit=crop',
  },
  {
    id: 'p2',
    name: '豆豆',
    type: 'dog',
    breed: '柴犬',
    age: 3,
    imageUrl: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?q=80&w=2069&auto=format&fit=crop',
  },
];
