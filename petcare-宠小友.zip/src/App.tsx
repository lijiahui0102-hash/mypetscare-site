import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, Search, MapPin, Plus, ChevronRight, Settings } from 'lucide-react';
import Navigation from './components/Navigation';
import ServiceCard from './components/ServiceCard';
import FeederCard from './components/FeederCard';
import { SERVICES, FEEDERS, MOCK_PETS } from './constants';
import * as Icons from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('home');

  const renderHome = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="grid grid-cols-12 gap-8 pb-32"
    >
      {/* Main Content Area */}
      <div className="col-span-12 lg:col-span-8 flex flex-col gap-8">
        
        {/* Welcome Card / Banner */}
        <div className="bg-gradient-to-br from-primary-400 to-primary-500 rounded-3xl p-8 text-white flex justify-between items-center shadow-xl shadow-primary-500/20">
          <div className="space-y-4">
            <h2 className="text-3xl font-bold">下午好，宠主</h2>
            <p className="opacity-90 max-w-sm text-lg font-light leading-snug">
              给毛孩子一个暖黄色的家。已有 50,000+ 家庭的选择，专业喂养师随时待命。
            </p>
            <div className="flex gap-3 pt-2">
              <button className="bg-white text-primary-600 px-6 py-2.5 rounded-xl font-bold text-sm shadow-sm hover:bg-primary-50 transition-colors">
                预约服务
              </button>
              <button className="bg-primary-600/30 backdrop-blur text-white px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-primary-600/50 transition-colors">
                查看进度
              </button>
            </div>
          </div>
          <div className="hidden sm:flex w-48 h-48 bg-white/20 rounded-full items-center justify-center p-4 relative overflow-hidden">
            <div className="w-32 h-32 bg-white rounded-3xl rotate-12 flex items-center justify-center overflow-hidden shadow-2xl">
              <img 
                src={MOCK_PETS[0].imageUrl} 
                className="scale-110 object-cover w-full h-full" 
                alt="Pet" 
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute bottom-2 right-4 bg-white text-primary-500 text-[10px] px-2 py-1 rounded-full font-bold uppercase tracking-wider shadow-md">
              In Service
            </div>
          </div>
        </div>

        {/* Services Section */}
        <section>
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-lg text-slate-900">专业上门喂养</h3>
            <div className="flex gap-2">
              <div className="w-2 h-2 rounded-full bg-primary-500"></div>
              <div className="w-2 h-2 rounded-full bg-primary-200"></div>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES.slice(0, 3).map((service) => (
              <ServiceCard
                key={service.id}
                service={service}
                onClick={() => console.log('Service selected:', service.title)}
              />
            ))}
          </div>
        </section>

        {/* Service Record Activity */}
        <div className="polish-card p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-lg">服务记录动态</h3>
            <button className="text-primary-500 text-sm font-medium">查看全部</button>
          </div>
          <div className="space-y-4">
            <div className="flex items-center gap-4 p-4 bg-slate-50/50 rounded-xl border border-slate-100">
              <div className="w-12 h-12 bg-primary-200 rounded-lg overflow-hidden shrink-0 border border-primary-300">
                <img src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?q=80&w=100&auto=format&fit=crop" alt="Pet Record" className="object-cover w-full h-full" />
              </div>
              <div className="flex-1">
                <div className="flex justify-between">
                  <h4 className="font-semibold text-sm">完成「日常喂食」服务</h4>
                  <span className="text-xs text-slate-400">目前 18:30</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">喂养师已上传 3张 照片。环境整洁，饮水已换。</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-4 bg-slate-50/50 rounded-xl opacity-60">
              <div className="w-12 h-12 bg-slate-200 rounded-lg overflow-hidden shrink-0 border border-slate-300">
                <img src="https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?q=80&w=100&auto=format&fit=crop" alt="Dog Record" className="object-cover w-full h-full" />
              </div>
              <div className="flex-1 text-slate-500">
                <div className="flex justify-between">
                  <h4 className="font-semibold text-sm">完成「陪玩 30min」服务</h4>
                  <span className="text-xs text-slate-400">10月24日</span>
                </div>
                <p className="text-xs mt-1">运动量达标，心理疏导良好。</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sidebar Area */}
      <div className="col-span-12 lg:col-span-4 space-y-6">
        <div className="polish-card p-6">
          <h3 className="font-bold text-lg mb-6">精选优质喂养师</h3>
          <div className="space-y-6">
            {FEEDERS.map((feeder) => (
              <div key={feeder.id} className="flex items-center gap-4 group cursor-pointer">
                <img className="w-12 h-12 rounded-xl object-cover border border-slate-100" src={feeder.avatarUrl} alt={feeder.name} referrerPolicy="no-referrer" />
                <div className="flex-1 border-b border-slate-50 pb-3 group-last:border-0">
                  <div className="flex justify-between items-start">
                    <h4 className="font-bold text-slate-900 text-sm">{feeder.name}</h4>
                    <span className="text-primary-500 font-bold text-sm">￥{feeder.price}<span className="text-[10px] text-slate-400 font-normal">/次</span></span>
                  </div>
                  <div className="flex items-center text-primary-400 text-[10px] mt-1 space-x-0.5">
                    <Icons.Star size={10} fill="currentColor" />
                    <Icons.Star size={10} fill="currentColor" />
                    <Icons.Star size={10} fill="currentColor" />
                    <Icons.Star size={10} fill="currentColor" />
                    <Icons.Star size={10} fill="currentColor" />
                    <span className="text-slate-400 ml-2">({feeder.reviews}评价)</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-8 py-3 bg-primary-100/30 text-primary-600 rounded-xl font-bold text-sm hover:bg-primary-100 transition-colors">
            查看更多喂养师
          </button>
        </div>

        {/* Membership Card */}
        <div className="bg-primary-900 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden group">
          <div className="relative z-10 space-y-2">
            <h4 className="font-bold text-lg italic tracking-wider">Join VIP Plan</h4>
            <p className="text-xs opacity-70">会员专享服务，上门费立减50%</p>
            <div className="pt-4 text-2xl font-bold">
              ￥19.9<span className="text-xs font-normal opacity-50 ml-1">/月</span>
            </div>
            <button className="w-full mt-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold transition-colors">
              立即开通
            </button>
          </div>
          <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-white/10 rounded-full group-hover:scale-110 transition-transform duration-500"></div>
          <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-white/5 rounded-full group-hover:scale-125 transition-transform duration-700"></div>
        </div>

        {/* My Pets Mini List */}
        <div className="polish-card p-6">
          <h3 className="font-bold text-base mb-4">我的毛孩子</h3>
          <div className="flex -space-x-4 mb-4">
            {MOCK_PETS.map(pet => (
              <div key={pet.id} className="w-12 h-12 rounded-full border-4 border-white overflow-hidden shadow-sm">
                <img src={pet.imageUrl} className="w-full h-full object-cover" alt={pet.name} />
              </div>
            ))}
            <div className="w-12 h-12 rounded-full border-4 border-white bg-slate-50 flex items-center justify-center text-slate-300">
              <Plus size={20} />
            </div>
          </div>
          <p className="text-[10px] text-slate-400 font-medium">已有 2 只宠物，管理档案</p>
        </div>
      </div>
    </motion.div>
  );

  const renderProfile = () => (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="pb-32 max-w-4xl mx-auto"
    >
      <div className="bg-white border border-primary-100 rounded-3xl p-8 mb-8 flex flex-col md:flex-row justify-between items-center gap-8 shadow-sm">
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 rounded-3xl border-4 border-primary-100 overflow-hidden shadow-xl">
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=user" alt="User Profile" referrerPolicy="no-referrer" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-slate-900">林先生</h1>
              <span className="text-[10px] bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full font-bold">VIP 会员</span>
            </div>
            <p className="text-slate-400 text-sm mt-1">已守护毛孩子 365 天 · 上海静安</p>
          </div>
        </div>
        <div className="flex gap-4">
          <button className="polish-button-secondary py-2">编辑资料</button>
          <button className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-400 border border-slate-100">
            <Settings size={20} />
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="polish-card p-0 overflow-hidden">
          <div className="p-6 border-b border-primary-50">
            <h3 className="font-bold text-lg">常用功能</h3>
          </div>
          <div className="divide-y divide-primary-50">
            {[
              { label: '我的订单', icon: 'Wallet', count: '12' },
              { label: '专属优惠券', icon: 'Ticket', count: '3张' },
              { label: '地址管理', icon: 'MapPin', count: '3个' },
              { label: '邀请有礼', icon: 'Gift', count: '得现金' },
            ].map((item) => {
              const Icon = (Icons as any)[item.icon];
              return (
                <button key={item.label} className="w-full px-6 py-5 flex justify-between items-center hover:bg-primary-50/50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="text-primary-500 w-10 h-10 bg-primary-50 rounded-xl flex items-center justify-center"><Icon size={20} /></div>
                    <span className="text-sm font-semibold text-slate-800">{item.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-primary-600 font-bold">{item.count}</span>
                    <ChevronRight size={16} className="text-slate-200" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="space-y-8">
          {/* Pet Stats Banner */}
          <div className="bg-primary-500 rounded-2xl p-6 text-white shadow-xl shadow-primary-500/20">
            <h4 className="font-bold mb-4">毛孩子概括</h4>
            <div className="flex justify-between items-end">
              <div>
                <p className="text-3xl font-bold">2</p>
                <p className="text-[10px] opacity-80">当前注册宠仔</p>
              </div>
              <img src={MOCK_PETS[1].imageUrl} className="w-16 h-16 rounded-2xl border-2 border-white/50 object-cover rotate-6" />
            </div>
          </div>

          <div className="polish-card bg-primary-900 border-none text-white overflow-hidden p-6 relative">
            <h4 className="font-bold mb-2">安全保障力</h4>
            <p className="text-xs opacity-60 mb-4">每一项服务均受专业保险覆盖</p>
            <div className="flex gap-4">
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center"><Icons.ShieldCheck size={16} /></div>
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center"><Icons.Camera size={16} /></div>
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center"><Icons.Video size={16} /></div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );

  return (
    <div className="bg-primary-50 min-h-screen">
      {/* Top Professional Header */}
      <div className="bg-white border-b border-primary-100 px-8 py-4 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-400 rounded-xl flex items-center justify-center shadow-lg shadow-primary-200/50">
             <Icons.Heart className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-primary-900">萌宠到家 <span className="text-primary-500 font-medium text-sm ml-1">| 专业上门喂养</span></h1>
        </div>
        <div className="flex items-center gap-6">
          <div className="hidden sm:flex items-center text-sm font-medium bg-primary-100/50 px-3 py-1.5 rounded-full text-primary-700 border border-primary-200">
            <Icons.MapPin className="w-4 h-4 mr-1.5" />
            上海市 · 静安区
          </div>
          <div className="relative cursor-pointer">
            <div className="w-2 h-2 bg-red-500 rounded-full absolute -top-0.5 -right-0.5 border-2 border-white"></div>
            <Icons.Bell className="w-6 h-6 text-slate-300" />
          </div>
          <img className="w-10 h-10 rounded-full border-2 border-primary-300 cursor-pointer" src="https://api.dicebear.com/7.x/avataaars/svg?seed=user" alt="Avatar" referrerPolicy="no-referrer" />
        </div>
      </div>

      <main className="max-w-7xl mx-auto p-4 sm:p-8">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && renderHome()}
          {activeTab === 'profile' && renderProfile()}
          {(activeTab === 'booking' || activeTab === 'chat') && (
            <motion.div
              key="wip"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="flex flex-col items-center justify-center min-h-[60vh] text-center"
            >
              <div className="w-24 h-24 bg-primary-100 rounded-[2rem] flex items-center justify-center text-primary-500 mb-8 rotate-12">
                <Plus size={40} className="rotate-45" />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-3">模块优化中</h2>
              <p className="text-slate-400 max-w-xs font-medium">
                为了保证极致的服务体验，我们正在进行系统级优化，请稍后再次访问。
              </p>
              <button
                onClick={() => setActiveTab('home')}
                className="mt-10 polish-button-primary"
              >
                返回大厅
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
      
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}
