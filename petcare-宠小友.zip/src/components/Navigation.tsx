import { motion } from 'motion/react';
import { Home, Calendar, MessageCircle, User } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Navigation({ activeTab, setActiveTab }: NavigationProps) {
  const tabs = [
    { id: 'home', label: '首页', icon: Home },
    { id: 'booking', label: '预约', icon: Calendar },
    { id: 'chat', label: '消息', icon: MessageCircle },
    { id: 'profile', label: '我的', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 flex justify-between items-center px-12 py-3 pb-8 z-50">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center gap-1 transition-colors ${
              isActive ? 'text-primary-500' : 'text-slate-400 hover:text-primary-500'
            }`}
            id={`nav-tab-${tab.id}`}
          >
            <Icon size={24} />
            <span className="text-[10px] font-bold">
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
