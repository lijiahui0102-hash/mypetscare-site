import { motion } from 'motion/react';
import { Star, MapPin } from 'lucide-react';
import { Feeder } from '../types';

interface FeederCardProps {
  feeder: Feeder;
  onClick: () => void;
}

export default function FeederCard({ feeder, onClick }: FeederCardProps) {
  return (
    <motion.div
      whileHover={{ y: -5 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="polish-card flex flex-col gap-4 cursor-pointer p-5"
      id={`feeder-card-${feeder.id}`}
    >
      <div className="flex gap-4">
        <div className="relative">
          <img
            src={feeder.avatarUrl}
            alt={feeder.name}
            className="w-14 h-14 rounded-xl object-cover border border-primary-100"
            referrerPolicy="no-referrer"
            id={`feeder-avatar-${feeder.id}`}
          />
          <div className="absolute -top-1 -right-1 bg-primary-500 text-white p-0.5 rounded-full border-2 border-white shadow-sm">
            <Star size={8} fill="currentColor" />
          </div>
        </div>
        
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-bold text-base text-slate-800">{feeder.name} <span className="ml-2 text-[10px] bg-primary-100 text-primary-700 px-1.5 py-0.5 rounded font-medium">实名认证</span></h3>
              <div className="flex items-center text-primary-500 text-xs mt-1">
                <Star size={12} fill="currentColor" className="mr-0.5" />
                <Star size={12} fill="currentColor" className="mr-0.5" />
                <Star size={12} fill="currentColor" className="mr-0.5" />
                <Star size={12} fill="currentColor" className="mr-0.5" />
                <Star size={12} fill="currentColor" className="mr-0.5" />
                <span className="text-slate-400 ml-1">({feeder.reviews}评价)</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-primary-600 font-bold text-base">¥{feeder.price}</span>
              <span className="text-[10px] text-slate-400 block font-normal">/次</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {feeder.tags.map((tag) => (
          <span
            key={tag}
            className="px-2.5 py-1 bg-primary-50 text-primary-700 text-[10px] font-bold rounded-lg border border-primary-100"
          >
            {tag}
          </span>
        ))}
      </div>

      <div className="flex items-center justify-between mt-2 pt-4 border-t border-slate-50">
        <div className="flex items-center gap-1 text-slate-400">
          <MapPin size={12} />
          <span className="text-[10px] font-medium">附近 1.2km | 浦东新区</span>
        </div>
        <button className="text-xs font-bold text-primary-600 px-3 py-1 bg-primary-50 rounded-full hover:bg-primary-100">
          立即预约
        </button>
      </div>
    </motion.div>
  );
}
