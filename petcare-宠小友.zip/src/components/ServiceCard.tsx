import { motion } from 'motion/react';
import * as Icons from 'lucide-react';
import { Service } from '../types';

interface ServiceCardProps {
  service: Service;
  onClick: () => void;
}

export default function ServiceCard({ service, onClick }: ServiceCardProps) {
  // @ts-ignore - Lucide icon names are strings
  const IconComponent = (Icons as any)[service.icon] || Icons.HelpCircle;

  return (
    <motion.div
      whileHover={{ y: -5, shadow: '0 20px 25px -5px rgb(245 158 11 / 0.1), 0 8px 10px -6px rgb(245 158 11 / 0.1)' }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="polish-card flex flex-col gap-3 min-w-[150px] cursor-pointer group"
      id={`service-card-${service.id}`}
    >
      <div className="w-12 h-12 bg-primary-50 text-primary-500 rounded-xl flex items-center justify-center text-xl group-hover:bg-primary-500 group-hover:text-white transition-all duration-300">
        <IconComponent size={24} />
      </div>
      <div>
        <h3 className="font-bold text-slate-800 text-sm whitespace-nowrap">{service.title}</h3>
        <p className="text-[10px] text-slate-400 font-medium line-clamp-1 mt-0.5">{service.description}</p>
      </div>
      <div className="mt-auto">
        <span className="font-bold text-primary-600 text-sm">¥{service.price}</span>
        <span className="text-[10px] text-slate-300 ml-1 font-normal">起</span>
      </div>
    </motion.div>
  );
}
