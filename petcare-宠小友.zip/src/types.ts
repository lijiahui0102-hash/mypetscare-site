export interface Pet {
  id: string;
  name: string;
  type: 'cat' | 'dog' | 'other';
  breed: string;
  age: number;
  imageUrl: string;
}

export interface Feeder {
  id: string;
  name: string;
  rating: number;
  reviews: number;
  price: number;
  avatarUrl: string;
  experience: string;
  tags: string[];
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  price: number;
}

export interface Booking {
  id: string;
  petId: string;
  feederId: string;
  serviceId: string;
  date: string;
  timeSlot: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
}
